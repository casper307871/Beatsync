"""
SAM CLI version
"""

__version__ = "1.145.1.dev202510170901"
